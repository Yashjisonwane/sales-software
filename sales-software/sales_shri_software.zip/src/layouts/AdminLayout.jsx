import { Link, Outlet, useLocation, useNavigate } from 'react-router-dom';
import { LayoutDashboard, Briefcase, Users, FolderOpen, MapPin, CreditCard, BarChart2, Settings, LogOut, Menu, X, ShieldAlert, Bell, Zap, Activity, Navigation, ClipboardList } from 'lucide-react';
import { useState, useRef, useEffect } from 'react';
import { useData } from '../context/DataContext';
import { useMarketplace } from '../context/MarketplaceContext';
import ConfirmationModal from '../components/ConfirmationModal';
import Toast from '../components/Toast';
import Sidebar from '../components/Sidebar';

const AdminLayout = () => {
    const [sidebarOpen, setSidebarOpen] = useState(true);
    const [isLogoutModalOpen, setIsLogoutModalOpen] = useState(false);
    const [notifMenuOpen, setNotifMenuOpen] = useState(false);
    const { notifications, toast, showToast, markNotificationRead, clearNotifications, currentUser, logout } = useMarketplace();
    const notifRef = useRef(null);
    const location = useLocation();
    const navigate = useNavigate();

    const unreadCount = (notifications || []).filter(n => !n.isRead).length;

    useEffect(() => {
        const handleClickOutside = (event) => {
          if (notifRef.current && !notifRef.current.contains(event.target)) {
            setNotifMenuOpen(false);
          }
        };
        document.addEventListener('mousedown', handleClickOutside);
        return () => document.removeEventListener('mousedown', handleClickOutside);
    }, []);

    const menuItems = [
        { icon: LayoutDashboard, label: 'Dashboard', path: '/admin/dashboard' },
        { icon: Briefcase, label: 'Leads', path: '/admin/leads' },
        { icon: ClipboardList, label: 'Jobs', path: '/admin/jobs' },
        { icon: Users, label: 'Professionals', path: '/admin/professionals' },
        { icon: FolderOpen, label: 'Categories', path: '/admin/categories' },
        { icon: MapPin, label: 'Locations', path: '/admin/locations' },
        { icon: Navigation, label: 'Live Tracking', path: '/admin/live-tracking' },
        { icon: CreditCard, label: 'Subscriptions', path: '/admin/subscriptions' },
        { icon: Bell, label: 'Notifications', path: '/admin/notifications' },
        { icon: BarChart2, label: 'Reports', path: '/admin/reports' },
        { icon: Settings, label: 'Settings', path: '/admin/settings' },
    ];

    return (
        <div className="min-h-screen flex bg-gray-50 text-gray-900 font-sans">
            <Sidebar
                isOpen={sidebarOpen}
                onClose={() => setSidebarOpen(false)}
                menuItems={menuItems}
                basePath="/admin"
                title="LeadMarket"
                logo={Zap}
                themeColor="blue"
                bottomActions={[
                    {
                        icon: LogOut,
                        label: 'Logout',
                        danger: true,
                        onClick: () => setIsLogoutModalOpen(true)
                    }
                ]}
            />

            {/* Main Content */}
            <main className="flex-1 flex flex-col min-w-0 h-[100dvh] overflow-hidden relative">
                {/* Header */}
                <header className="h-16 bg-white border-b border-gray-200 flex items-center justify-between px-4 sm:px-6 shrink-0 sticky top-0 z-30">
                    <div className="flex items-center gap-2 sm:gap-4 min-w-0">
                        <button
                            type="button"
                            onClick={(e) => { e.stopPropagation(); setSidebarOpen(!sidebarOpen); }}
                            className="relative p-2 rounded-lg text-gray-500 hover:bg-gray-100 hover:text-gray-700 transition-all shrink-0 cursor-pointer active:scale-95"
                        >
                            <Menu size={20} className="sm:w-[22px]" />
                        </button>
                        <div className="min-w-0">
                            <h1 className="text-sm sm:text-base font-bold text-gray-800 truncate">
                                {menuItems.find(i => location.pathname.startsWith(i.path))?.label ||
                                    (location.pathname === '/admin/settings' ? 'Settings' : 'Marketplace Admin')}
                            </h1>
                            <p className="hidden xs:block text-[10px] sm:text-xs text-gray-400 truncate">Service Management Platform</p>
                        </div>
                    </div>

                    <div className="flex items-center gap-2 sm:gap-4 shrink-0">


                        <div className="relative" ref={notifRef}>
                            <button
                                className="relative p-2 rounded-lg text-gray-500 hover:bg-gray-100 hover:text-gray-700 transition-colors"
                                onClick={() => setNotifMenuOpen(!notifMenuOpen)}
                            >
                                <Bell size={18} className="sm:w-5" />
                                {unreadCount > 0 && (
                                    <span className="absolute top-1 right-1 w-4 h-4 bg-red-500 text-white text-[10px] font-bold rounded-full flex items-center justify-center">
                                        {unreadCount}
                                    </span>
                                )}
                            </button>

                            {notifMenuOpen && (
                                <div className="absolute right-0 mt-2 w-80 bg-white rounded-xl shadow-2xl border border-gray-100 overflow-hidden z-50 animate-in fade-in slide-in-from-top-2 duration-200">
                                    <div className="p-4 border-b border-gray-100 flex items-center justify-between bg-gray-50/50">
                                        <h3 className="font-bold text-gray-900 text-sm">Notifications</h3>
                                        {unreadCount > 0 && (
                                            <button 
                                                onClick={clearNotifications}
                                                className="text-[10px] font-bold text-blue-600 hover:underline uppercase tracking-tight"
                                            >
                                                Clear All
                                            </button>
                                        )}
                                    </div>
                                    <div className="max-h-[400px] overflow-y-auto custom-scrollbar">
                                        {(notifications || []).length > 0 ? (
                                            notifications.map((n) => (
                                                <div 
                                                    key={n.id}
                                                    onClick={() => !n.isRead && markNotificationRead(n.id)}
                                                    className={`p-4 border-b border-gray-50 hover:bg-gray-50 transition-colors cursor-pointer relative ${!n.isRead ? 'bg-blue-50/30' : ''}`}
                                                >
                                                    {!n.isRead && (
                                                        <div className="absolute top-4 right-4 w-2 h-2 bg-blue-600 rounded-full"></div>
                                                    )}
                                                    <p className="text-[11px] font-bold text-blue-600 uppercase tracking-widest mb-1">{n.type || 'System'}</p>
                                                    <h4 className="text-xs font-bold text-gray-900 mb-1">{n.title}</h4>
                                                    <p className="text-[11px] text-gray-500 line-clamp-2 leading-relaxed">{n.message}</p>
                                                    <p className="text-[9px] text-gray-400 mt-2 font-medium">
                                                        {new Date(n.createdAt).toLocaleString([], { dateStyle: 'short', timeStyle: 'short' })}
                                                    </p>
                                                </div>
                                            ))
                                        ) : (
                                            <div className="p-10 text-center">
                                                <div className="w-12 h-12 bg-gray-50 rounded-full flex items-center justify-center mx-auto mb-3">
                                                    <Bell size={20} className="text-gray-300" />
                                                </div>
                                                <p className="text-xs text-gray-400 font-medium">No new notifications</p>
                                            </div>
                                        )}
                                    </div>
                                    <div className="p-3 border-t border-gray-100 bg-gray-50/50 text-center">
                                        <Link to="/admin/notifications" onClick={() => setNotifMenuOpen(false)} className="text-[11px] font-bold text-gray-500 hover:text-gray-900 underline transition-colors">
                                            View all activity
                                        </Link>
                                    </div>
                                </div>
                            )}
                        </div>
                        <div className="flex items-center gap-2 sm:gap-3 cursor-pointer" onClick={() => navigate('/admin/settings')}>
                            <div className="w-8 h-8 sm:w-9 sm:h-9 bg-blue-600 text-white rounded-lg flex items-center justify-center font-bold text-xs sm:text-sm shadow-md shrink-0">
                                {currentUser?.name?.charAt(0) || 'A'}
                            </div>
                            <div className="hidden sm:block text-left min-w-0">
                                <p className="text-xs sm:text-sm font-semibold text-gray-800 truncate max-w-[100px]">
                                    {currentUser?.name || 'Admin'}
                                </p>
                                <p className="text-[10px] text-gray-400 truncate uppercase font-extrabold tracking-widest">
                                    {currentUser?.role === 'WORKER' ? 'PROFESSIONAL' : (currentUser?.role || 'ADMIN')}
                                </p>
                            </div>
                        </div>
                    </div>
                </header>

                {/* Page Content */}
                <div className="flex-1 overflow-y-auto p-4 sm:p-6 bg-gray-50 custom-scrollbar">
                    <div className="max-w-screen-2xl mx-auto w-full">
                        <Outlet />
                    </div>
                </div>
            </main>

            <ConfirmationModal
                isOpen={isLogoutModalOpen}
                onClose={() => setIsLogoutModalOpen(false)}
                onConfirm={() => {
                    logout();
                    navigate('/login');
                }}
                title="Terminate Session"
                message="Are you sure you want to sign out of your administrator account?"
                icon={ShieldAlert}
                confirmText="Sign Out"
                type="danger"
            />

            {toast && (
                <Toast
                    message={toast.message}
                    type={toast.type}
                    onClose={() => showToast(null)}
                />
            )}
        </div>
    );
};

export default AdminLayout;
